#pragma once
#include <vector>
#include <stdexcept>

/*__BROASCASTING A Vector__*/
inline std::vector<size_t> __openblao_broadcast(const std::vector<size_t>& a, const std::vector<size_t>& b)
{
    size_t na = a.size();
    size_t nb = b.size();
    size_t n  = std::max(na, nb);

    std::vector<size_t> result(n);

    for (size_t i = 0; i < n; ++i) {
        size_t a_dim = (i < na) ? a[na - 1 - i] : 1;
        size_t b_dim = (i < nb) ? b[nb - 1 - i] : 1;

        if (a_dim == b_dim || a_dim == 1 || b_dim == 1) {
            result[n - 1 - i] = std::max(a_dim, b_dim);
        } else {
            throw std::runtime_error("Broadcast shape mismatch");
        }
    }

    return result;
}